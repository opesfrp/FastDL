# Warmod-css-v91

## Warmode for Counter-Strike: Source v91 

 For Sourcemod v-1.10.0

 Original Creator: Twelve-60 (GameTech)
 http://www.gametech.com.au/warmod/

 Ported By @TheNomUser  Disscord > NomUser:9115

to install download sourcemod
http://www.sourcemod.net/downloads.php?branch=stable
extract the files inside cstrike folder and paste mod files

i made this little port in one day btw

Changes:
Remove:
  Includes: Socket, Steamtools, Autoupdate.
 	Core: multiple restarts, Livewire.

Added:
 	Core: In game scoreboard Update.
  
 	i cant replace the deprecated vars because -_-
 	report bugs on Issues or discord > NomUser:9115
 		


